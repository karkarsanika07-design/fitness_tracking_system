<?php
session_start();
include("db.php");

if(!isset($_SESSION['email']))
{
    header("Location:signin.html");
    exit();
}

$email=$_SESSION['email'];

$sql="SELECT * FROM fitness_details
WHERE user_email='$email'
ORDER BY id DESC
LIMIT 1";

$result=mysqli_query($conn,$sql);

if(mysqli_num_rows($result)>0)
{
    $row=mysqli_fetch_assoc($result);

    $name=$row['fullname'];
    $date=$row['date'];
    $weight=$row['weight'];
    $height=$row['height'];
    $steps=$row['steps'];
    $calories=$row['calories'];
    $water=$row['water'];
    $sleep=$row['sleep'];
    $workout=$row['workout'];
    $duration=$row['duration'];
    $heart=$row['heart'];
    $goal=$row['goal'];

    $bmi=round($weight/(($height/100)*($height/100)),2);

    $percent=round(($steps/10000)*100);

    if($percent>100)
    {
        $percent=100;
    }
}
else
{
    die("No fitness record found.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Fitness Dashboard</title>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;
}

body{
background:#f5f7fa;
}

.header{
background:#009688;
color:white;
padding:20px 40px;
display:flex;
justify-content:space-between;
align-items:center;
}

.logout{
background:white;
color:#009688;
padding:10px 20px;
border:none;
border-radius:8px;
cursor:pointer;
font-weight:bold;
}

.container{
padding:30px;
}

.cards{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:20px;
margin-bottom:30px;
}

.card{
background:white;
padding:25px;
border-radius:12px;
text-align:center;
box-shadow:0 5px 15px rgba(0,0,0,.1);
}

.card h3{
margin-bottom:10px;
color:#555;
}

.card h1{
color:#009688;
}

table{
width:100%;
border-collapse:collapse;
background:white;
box-shadow:0 5px 15px rgba(0,0,0,.1);
}

th{
background:#009688;
color:white;
padding:15px;
}

td{
padding:15px;
text-align:center;
border-bottom:1px solid #ddd;
}

.progress{
margin-top:30px;
background:white;
padding:20px;
border-radius:10px;
box-shadow:0 5px 15px rgba(0,0,0,.1);
}

.bar{
width:100%;
height:20px;
background:#ddd;
border-radius:20px;
overflow:hidden;
}

.fill{
height:100%;
background:#00c853;
}

</style>

</head>

<body>

<div class="header">

<h2>
🏋 Fitness Dashboard - Welcome
<?php echo $name; ?>
</h2>

<a href="logout.php">
<button class="logout">
Logout
</button>
</a>

</div>

<div class="container">

<div class="cards">

<div class="card">
<h3>👣 Steps</h3>
<h1><?php echo $steps; ?></h1>
</div>

<div class="card">
<h3>🔥 Calories</h3>
<h1><?php echo $calories; ?></h1>
</div>

<div class="card">
<h3>💧 Water</h3>
<h1><?php echo $water; ?> L</h1>
</div>

<div class="card">
<h3>😴 Sleep</h3>
<h1><?php echo $sleep; ?> Hrs</h1>
</div>

<div class="card">
<h3>⚖ Weight</h3>
<h1><?php echo $weight; ?> Kg</h1>
</div>

<div class="card">
<h3>🏃 Workout</h3>
<h1><?php echo $duration; ?> Min</h1>
</div>

<div class="card">
<h3>📊 BMI</h3>
<h1><?php echo $bmi; ?></h1>
</div>
</div>


<h2 style="color:#009688;margin-bottom:15px;">
Today's Fitness Details
</h2>


<table>

<tr>
<th>Date</th>
<th>Workout</th>
<th>Duration</th>
<th>Heart Rate</th>
<th>Goal</th>
</tr>


<tr>

<td>
<?php echo $date; ?>
</td>

<td>
<?php echo $workout; ?>
</td>

<td>
<?php echo $duration; ?> Min
</td>

<td>
<?php echo $heart; ?> BPM
</td>

<td>
<?php echo $goal; ?>
</td>

</tr>

</table>



<div class="progress">

<h2>
Daily Goal Progress
</h2>


<p style="margin-top:15px;">

<?php echo $percent; ?>% Completed 
(<?php echo $steps; ?>/10000 Steps)

</p>


<div class="bar">

<div class="fill"
style="width:<?php echo $percent; ?>%">
</div>

</div>



<br><br>


<h2 style="text-align:center;">
Fitness Progress Chart
</h2>


<div style="width:350px;margin:auto;">

<canvas id="progressChart"></canvas>

</div>


</div>


</div>



<script>


let daily =
<?php echo $percent; ?>;


let weekly =
Math.round((<?php echo $steps; ?> * 7 / 70000) * 100);


if(weekly > 100)
{
    weekly = 100;
}


let monthly =
Math.round((<?php echo $steps; ?> * 30 / 300000) * 100);


if(monthly > 100)
{
    monthly = 100;
}



new Chart(
document.getElementById("progressChart"),
{

type:"pie",


data:
{

labels:
[
"Daily",
"Weekly",
"Monthly"
],


datasets:
[{

data:
[
daily,
weekly,
monthly
],


backgroundColor:
[

"#00c853",

"#03A9F4",

"#FF9800"

]

}]

},


options:
{

responsive:true,


plugins:
{

legend:
{

position:"bottom"

}

}

}

}

);



</script>


</body>

</html>