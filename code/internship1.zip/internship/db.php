<?php

$host = "localhost";
$user = "root";
$password = "";
$dbname = "fitness_tracking";

// Create Connection
$conn = mysqli_connect($host, $user, $password, $dbname);

// Check Connection
if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}

// Optional: Set UTF-8
mysqli_set_charset($conn, "utf8");

?>