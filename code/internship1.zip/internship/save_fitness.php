<?php

session_start();

include("db.php");


// Check login

if(!isset($_SESSION['email']))
{

    header("Location: signin.html");
    exit();

}



if($_SERVER["REQUEST_METHOD"] == "POST")
{


    $email = $_SESSION['email'];


    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $date = $_POST['date'];
    $weight = $_POST['weight'];
    $height = $_POST['height'];
    $steps = $_POST['steps'];
    $calories = $_POST['calories'];
    $water = $_POST['water'];
    $sleep = $_POST['sleep'];

    $workout = mysqli_real_escape_string(
        $conn,
        $_POST['workout']
    );

    $duration = $_POST['duration'];
    $heart = $_POST['heart'];

    $goal = mysqli_real_escape_string(
        $conn,
        $_POST['goal']
    );

    $notes = mysqli_real_escape_string(
        $conn,
        $_POST['notes']
    );



    $sql = "INSERT INTO fitness_details

    (
    user_email,
    fullname,
    `date`,
    weight,
    height,
    steps,
    calories,
    water,
    sleep,
    workout,
    duration,
    heart,
    goal,
    notes
    )

    VALUES

    (

    '$email',
    '$name',
    '$date',
    '$weight',
    '$height',
    '$steps',
    '$calories',
    '$water',
    '$sleep',
    '$workout',
    '$duration',
    '$heart',
    '$goal',
    '$notes'

    )";




    if(mysqli_query($conn,$sql))
    {

        echo "

        <script>

        alert('Fitness Details Saved Successfully');

        window.location='dashboard.php';

        </script>

        ";

    }

    else
    {

        echo "

        <script>

        alert('Database Error: ".mysqli_error($conn)."');

        window.location='fitness.html';

        </script>

        ";

    }


}



mysqli_close($conn);


?>