<?php
session_start();

include("db.php");

if(isset($_POST['email']) && isset($_POST['password']))
{
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0)
    {
        $row = mysqli_fetch_assoc($result);

       if(password_verify($password, $row['password']))
{
    $_SESSION['email'] = $email;
    $_SESSION['name'] = $row['name'];

    header("Location: fitness.html");
    exit();
}
        else
        {
            echo "<script>
                    alert('Incorrect Password!');
                    window.location='signin.html';
                  </script>";
        }
    }
    else
    {
        echo "<script>
                alert('User Not Found!');
                window.location='signin.html';
              </script>";
    }
}
else
{
    echo "<script>
            alert('Invalid Request!');
            window.location='signin.html';
          </script>";
}

mysqli_close($conn);
?>