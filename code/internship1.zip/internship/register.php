<?php
include("db.php");

if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['password']))
{
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Check if email already exists
    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");

    if(mysqli_num_rows($check) > 0)
    {
        echo "<script>
                alert('Email Already Exists');
                window.location='register.html';
              </script>";
    }
    else
    {
        $password = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users(name,email,password)
                VALUES('$name','$email','$password')";

        if(mysqli_query($conn, $sql))
        {
            echo "<script>
                    alert('Registration Successful');
                    window.location='signin.html';
                  </script>";
        }
        else
        {
            echo "Database Error : " . mysqli_error($conn);
        }
    }
}
else
{
    echo "Invalid Request";
}

mysqli_close($conn);
?>